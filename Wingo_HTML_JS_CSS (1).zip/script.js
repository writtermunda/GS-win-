let timeLeft = 180;
const timerEl = document.getElementById("timer");

const countdown = setInterval(() => {
  timeLeft--;
  timerEl.textContent = timeLeft;
  if (timeLeft <= 0) {
    clearInterval(countdown);
    showResult();
  }
}, 1000);

function placeBet(color) {
  alert("You placed a bet on: " + color);
}

function showResult() {
  const result = Math.floor(Math.random() * 10);
  document.getElementById("result-number").textContent = result;
}
